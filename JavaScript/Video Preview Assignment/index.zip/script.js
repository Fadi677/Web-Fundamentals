// console.log("page loaded...")
function plav(fadi){
    fadi.play();
}
function pausee(element){
    element.pause();
}