function alertme(){
    alert("Loading weather report...")
}
function Accept(){
    var box=document.querySelector('footer');
    box.remove();
}

function c2f(temp) {
    return Math.floor(9/5*temp+32);
}

function f2c(temp) {
    return Math.floor(5/9*(temp-32));
}

function exchange(element) {
    console.log(element.value);
    for(var i=1; i<9; i++) {
        var tempSpan = document.querySelector("#temp" + i);
        var tempVal = parseInt(tempSpan.innerText);
        if(element.value == "°C") {
            tempSpan.innerText = f2c(tempVal);
        } else {
            tempSpan.innerText = c2f(tempVal);
        }
    }
}