for(var j=100;j>=0;j--){
    if(j%3==0){
        console.log(j)
    }
}