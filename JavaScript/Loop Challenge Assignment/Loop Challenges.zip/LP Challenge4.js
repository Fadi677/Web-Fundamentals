var sum=0;
for(var i=1;i<=100;i++){
    var sum=sum+i;
}
console.log(sum);