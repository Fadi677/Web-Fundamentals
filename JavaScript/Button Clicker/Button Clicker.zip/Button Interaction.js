function removeme(element){
    element.remove();
}
function signout(element){
    element.innerText="Log Out";
}