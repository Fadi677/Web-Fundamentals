function likes_counter(element){
    var likes1=document.getElementById(element);
    console.log(likes1.innerHTML);
    likes1.innerHTML++;
}